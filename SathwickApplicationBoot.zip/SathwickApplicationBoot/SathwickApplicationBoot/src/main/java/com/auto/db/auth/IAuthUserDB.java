package com.auto.db.auth;

import com.auto.entity.auth.RegisterUser;

public interface IAuthUserDB {

	Boolean registerUserDB(RegisterUser authuser);

	String loginUserDB(RegisterUser authuser,String token);

	String logoutUserDB(String apiKey);

	RegisterUser authenAndauthorDB(String apiKey);

}
