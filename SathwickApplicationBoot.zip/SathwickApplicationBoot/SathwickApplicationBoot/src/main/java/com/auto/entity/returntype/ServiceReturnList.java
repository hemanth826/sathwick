package com.auto.entity.returntype;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceReturnList<T> extends ServiceReturn<T> {
	@JsonProperty(value = "rs")
	private List<T> result;

	private Long count=0L;
	
	public List<T> getResult() {
		return result;
	}

	public void setResult(List<T> result) {
		if(result!=null){
			setCount(result.size());
		}
		this.result = result;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}
	public void setCount(Integer count) {
		this.count = new Long(count);
	}

}
