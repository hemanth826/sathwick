package com.auto.entity.auth;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel
public class RegisterUser {
	
	private String userName,password,role,token;
	@ApiModelProperty(position = 0, required = true, hidden=false)
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	@ApiModelProperty(position = 1, required = true, hidden=false)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	@ApiModelProperty(position = 2, required = true,allowableValues = "ADMIN, USER", hidden=false)
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}
	@ApiModelProperty(position = 3, required = true, hidden=true)
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
}
