package com.auto.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.auto.entity.auth.RegisterUser;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class TokenHandler {

		private static final String CLAIM_KEY_USERNAME = "keyUserName";
		private static final String CLAIM_KEY_CREATED = "createdDate";
		private static final String CLAIM_KEY_PASSWORD = "keyPassword";
		 

		@Value("${security.auth.secret}")
		private String secret;

		@Value("${security.auth.expiration}")
		private Long expiration;

		public String getUsernameFromToken(String token) {
			String username;
			try {
				final Claims claims = getClaimsFromToken(token);
				username = (String) claims.get(CLAIM_KEY_USERNAME);
			} catch (Exception e) {
				username = null;
			}
			return username;
		}
		public String getPasswordFromToken(String token) {
			String password;

			try {
				final Claims claims = getClaimsFromToken(token);
				password = (String) claims.get(CLAIM_KEY_PASSWORD);
			} catch (Exception e) {
				password = null;
			}
			return password;
		}
		public Date getCreatedDateFromToken(String token) {
			Date created;
			try {
				final Claims claims = getClaimsFromToken(token);
				created = new Date((Long) claims.get(CLAIM_KEY_CREATED));
			} catch (Exception e) {
				created = null;
			}
			return created;
		}

		public Date getExpirationDateFromToken(String token) {
			Date expiration;
			try {
				final Claims claims = getClaimsFromToken(token);
				expiration = claims.getExpiration();
			} catch (Exception e) {
				expiration = null;
			}
			return expiration;
		}
	

		private Claims getClaimsFromToken(String token) {
			Claims claims;
			try {
				claims = Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
			} catch (Exception e) {
				claims = null;
			}
			return claims;
		}


		public String generateToken(RegisterUser register) {
			Map<String, Object> claims = new HashMap<String, Object>();
			claims.put(CLAIM_KEY_USERNAME, register.getUserName());    
			claims.put(CLAIM_KEY_PASSWORD, register.getPassword());  
			claims.put(CLAIM_KEY_CREATED, new Date());
			return generateToken(claims);
		}


		public String generateToken(Map<String, Object> claims) {
			return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS512, secret).compact();
		}	
		
		
}

