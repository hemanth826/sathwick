package com.auto.db.auth.impl;

import org.apache.log4j.Logger;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.stereotype.Repository;

import com.auto.db.auth.IAuthUserDB;
import com.auto.entity.auth.RegisterUser;
import com.auto.util.mongodb.MongoDbConfig;
import com.google.gson.Gson;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOptions;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;

@Repository
public class AuthUserDB implements IAuthUserDB {
	private static final Logger logger = Logger.getLogger(AuthUserDB.class);

	@Override
	public Boolean registerUserDB(RegisterUser authUser) {
		try {
			authUser.setToken("");
			MongoCollection<Document> mongoCollection = MongoDbConfig.mongoCollection;
			Bson filter = Filters.eq("userName", authUser.getUserName());
			boolean hasNext = mongoCollection.find(filter).cursor().hasNext();
			if (!hasNext) {
				Gson gson = new Gson();
				String json = gson.toJson(authUser);
				MongoDbConfig.insertDocument(json);
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			logger.error("insertDocument--" + e);
		}

		return false;
	}

	@Override
	public String loginUserDB(RegisterUser authUser, String token) {
		try {
			MongoCollection<Document> mongoCollection = MongoDbConfig.mongoCollection;
			Bson filter = Filters.and(Filters.eq("userName", authUser.getUserName()),
					Filters.eq("password", authUser.getPassword()));
			boolean hasNext = mongoCollection.find(filter).cursor().hasNext();
			if (hasNext) {
				Gson gson = new Gson();
				String json = gson.toJson(authUser);
				// Document toUpdate = new Document();
				Document parse = mongoCollection.find(filter).cursor().next();
				parse.append("token", token);
				UpdateResult replaceOne = mongoCollection.replaceOne(filter, parse);
				System.out.println("updateOne--" + replaceOne);				
				return token;
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

	@Override
	public RegisterUser authenAndauthorDB(String apiKey) {
		MongoCollection<Document> mongoCollection = MongoDbConfig.mongoCollection;
		Bson filter = Filters.eq("token", apiKey);
		 MongoCursor<Document> cursor2 = mongoCollection.find(filter).cursor();//.hasNext();
		 if(cursor2.hasNext()) {
			Document document = mongoCollection.find(filter).cursor().next();
			String json = document.toJson();
			Gson gson = new Gson();
			return gson.fromJson(json, RegisterUser.class);
		 }
		return null;
	}	
	
	
	@Override
	public String logoutUserDB(String apiKey) {
		MongoCollection<Document> mongoCollection = MongoDbConfig.mongoCollection;
		Bson filter = Filters.eq("token", apiKey);
		 MongoCursor<Document> cursor2 = mongoCollection.find(filter).cursor();//.hasNext();
		 if(cursor2.hasNext()) {
			Document document = mongoCollection.find(filter).cursor().next();
			document.append("token","");
			UpdateResult replaceOne = mongoCollection.replaceOne(filter, document); 
			System.out.println("replaceOne---"+replaceOne);
			long modifiedCount = replaceOne.getModifiedCount();
			if(modifiedCount>0) {
				return "logout succesfully";
			}
		 }
		return "logout failed";
	}



}
