package com.auto.entity.returntype;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public abstract class ServiceReturn<T> {
	@JsonProperty(value = "sc")
	private Integer statusCode;

	@JsonIgnore
	private Class<T> classType;

	public Class<T> getClassType() {
		return classType;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

	public void setClassType(Class<T> classType) {
		this.classType = classType;
	}

	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
}
