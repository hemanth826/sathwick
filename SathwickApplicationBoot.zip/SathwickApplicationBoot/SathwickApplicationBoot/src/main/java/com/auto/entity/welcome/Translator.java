package com.auto.entity.welcome;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel
public class Translator {
String fromLang,toLang,text;
@ApiModelProperty(position = 0, required = true, hidden=false)
public String getFromLang() {
	return fromLang;
}
public void setFromLang(String fromLang) {
	this.fromLang = fromLang;
}
@ApiModelProperty(position = 1, required = true, hidden=false)
public String getToLang() {
	return toLang;
}

public void setToLang(String toLang) {
	this.toLang = toLang;
}
@ApiModelProperty(position = 2, required = true, hidden=false)
public String getText() {
	return text;
}

public void setText(String text) {
	this.text = text;
}
}
