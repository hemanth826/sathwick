package com.auto.ctrl.auth.service.impl;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.auto.ctrl.auth.service.IAuthUserService;
import com.auto.db.auth.IAuthUserDB;
import com.auto.entity.auth.RegisterUser;
import com.auto.entity.returntype.ServiceReturnSingle;
import com.auto.util.TokenHandler;

@Service
public class AuthUserService implements IAuthUserService {
	private static final Logger logger = Logger.getLogger(AuthUserService.class);

	@Autowired
	IAuthUserDB authUserDB;
	@Autowired
	TokenHandler tokenHandler;

	@Override
	public ServiceReturnSingle<String> registerUserService(RegisterUser authuser) {
		Boolean isRegisterDB=authUserDB.registerUserDB(authuser);
		ServiceReturnSingle<String> serviceReturnSingle=new ServiceReturnSingle<String>();
		String response=isRegisterDB?"Registeration has been succesfully.":"UserName has been already existed.";
		serviceReturnSingle.setResult(response);
		int httpCode=isRegisterDB?HttpStatus.OK.value():HttpStatus.OK.value();
		serviceReturnSingle.setStatusCode(httpCode);
		return serviceReturnSingle;
	}

	@Override
	public ServiceReturnSingle<String> loginUserService(RegisterUser authuser) {
		ServiceReturnSingle<String> serviceReturnSingle=new ServiceReturnSingle<String>();
		String generateToken = tokenHandler.generateToken(authuser);

		try {
			String token=authUserDB.loginUserDB(authuser,generateToken);
			String response=(token.equals(""))?"Authentication failed.":token;
			serviceReturnSingle.setResult(response);
			int httpCode=token.equals("")?HttpStatus.FORBIDDEN.value():HttpStatus.OK.value();
			serviceReturnSingle.setStatusCode(httpCode);
		} catch (Exception e) {
			logger.error("loginUserService Exception-- "+e);
		}
		return serviceReturnSingle;
	}

	@Override
	public ServiceReturnSingle<RegisterUser> authenAndauthorService(String apiKey) {
		RegisterUser authenAndauthorDB = authUserDB.authenAndauthorDB(apiKey);
		ServiceReturnSingle<RegisterUser> serviceReturnSingle=new ServiceReturnSingle<RegisterUser>();
		serviceReturnSingle.setStatusCode(HttpStatus.OK.value());
		serviceReturnSingle.setResult(authenAndauthorDB);
		return serviceReturnSingle;
	}

	@Override
	public ServiceReturnSingle<String> logoutUserService(String apiKey) {
		String result=authUserDB.logoutUserDB(apiKey);
		ServiceReturnSingle<String> serviceReturnSingle=new ServiceReturnSingle<String>();
		serviceReturnSingle.setStatusCode(HttpStatus.OK.value());
		serviceReturnSingle.setResult(result);
		return serviceReturnSingle;
	}

}
