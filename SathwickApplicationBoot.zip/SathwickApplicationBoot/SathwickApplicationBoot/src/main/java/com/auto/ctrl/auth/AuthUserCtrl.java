package com.auto.ctrl.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.auto.ctrl.auth.service.IAuthUserService;
import com.auto.entity.auth.RegisterUser;
import com.auto.entity.returntype.ServiceReturnSingle;

@RestController
@RequestMapping("authuserctrl")
@CrossOrigin(origins = "*",maxAge=3600)
public class AuthUserCtrl {
	@Autowired
	IAuthUserService authUserService;
	
	//AuthUser
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/registeruserctrl", method = RequestMethod.POST,consumes=MediaType.APPLICATION_OCTET_STREAM_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ServiceReturnSingle> registerUserCtrl(RegisterUser authuser) {
		ServiceReturnSingle<String> serviceReturnSingle=authUserService.registerUserService(authuser);
		return ResponseEntity.ok(serviceReturnSingle);
	}	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/loginuserctrl", method = RequestMethod.POST,consumes=MediaType.APPLICATION_OCTET_STREAM_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ServiceReturnSingle> loginUserCtrl(String userName,String password) {
		RegisterUser authuser=new RegisterUser();
		authuser.setUserName(userName);
		authuser.setPassword(password);
		ServiceReturnSingle<String> serviceReturnSingle=authUserService.loginUserService(authuser);
		return ResponseEntity.ok(serviceReturnSingle);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/authenticationCtrl", method = RequestMethod.GET,consumes=MediaType.APPLICATION_OCTET_STREAM_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ServiceReturnSingle> authenicationCtrl(String apiKey) {
		ServiceReturnSingle<RegisterUser> serviceReturnSingle=authUserService.authenAndauthorService(apiKey);
		return ResponseEntity.ok(serviceReturnSingle);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value = "/logoutUserctrl", method = RequestMethod.POST,consumes=MediaType.APPLICATION_OCTET_STREAM_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ServiceReturnSingle> logoutUserCtrl(String apiKey) {
		ServiceReturnSingle<String> serviceReturnSingle=authUserService.logoutUserService(apiKey);
		return ResponseEntity.ok(serviceReturnSingle);
	}
}
