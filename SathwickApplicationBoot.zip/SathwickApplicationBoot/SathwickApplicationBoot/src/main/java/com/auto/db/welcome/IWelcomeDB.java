package com.auto.db.welcome;

import java.util.List;

import com.auto.entity.auth.RegisterUser;

public interface IWelcomeDB {

	List<RegisterUser> getAllUserListDB();

	Boolean deleteUserDB(String userName);


}
