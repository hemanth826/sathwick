package com.auto.ctrl.welcome;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.auto.ctrl.welcome.service.IWelcomeService;
import com.auto.entity.auth.RegisterUser;
import com.auto.entity.returntype.ServiceReturnList;
import com.auto.entity.returntype.ServiceReturnSingle;
import com.auto.entity.welcome.Translator;
import com.google.j2objc.annotations.ReflectionSupport;

@RestController
@RequestMapping("welcomectrl")
@CrossOrigin(origins = "*",maxAge=3600)
public class WelcomeCtrl {
	@Autowired
	IWelcomeService welcomeService;
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="/allUserctrl",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)	
	public ResponseEntity<ServiceReturnList> allUserCtrl(String apiKey ){
		ServiceReturnList<RegisterUser> returnList=welcomeService.allUserService( apiKey);
		return ResponseEntity.ok(returnList);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="/deleteUserctrl",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)	
	public ResponseEntity<ServiceReturnSingle> deleteUserCtrl(String apiKey,String userName ){
		ServiceReturnSingle<String> return1=welcomeService.deleteUserService( apiKey,userName);
		return ResponseEntity.ok(return1);
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping(value="/welcomeCtrl",method=RequestMethod.POST,produces=MediaType.APPLICATION_JSON_VALUE)	
	public ResponseEntity<ServiceReturnSingle> welcomeCtrl(){
		ServiceReturnSingle<String> return1=new ServiceReturnSingle<String>();
		return1.setResult("welcome");
		return1.setStatusCode(HttpStatus.OK.value());
		return ResponseEntity.ok(return1);
	}
}
