package com.auto.ctrl.auth.service;

import com.auto.entity.auth.RegisterUser;
import com.auto.entity.returntype.ServiceReturnSingle;

public interface IAuthUserService {

	ServiceReturnSingle<String> registerUserService(RegisterUser authuser);

	ServiceReturnSingle<String> loginUserService(RegisterUser authuser);

	ServiceReturnSingle<RegisterUser> authenAndauthorService(String apiKey);

	ServiceReturnSingle<String> logoutUserService(String apiKey);

}
