package com.auto.util.mongodb;
import org.apache.log4j.Logger;
import org.bson.Document;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDbConfig {
	private static final Logger logger = Logger.getLogger(MongoDbConfig.class);
	
	public static  MongoCollection<Document> mongoCollection= mongoCollection();
	
	@SuppressWarnings("resource")
	public static MongoCollection<Document> mongoCollection() {
		try {
			logger.info("MongoCollection has been initiated");
			MongoClientURI uri = new MongoClientURI("mongodb://hemu:1234@ds021895.mlab.com:21895/faveods?retryWrites=false");
			MongoClient client = new MongoClient(uri);
			MongoDatabase database=client.getDatabase(uri.getDatabase());
			 MongoCollection<Document> collection = database.getCollection("FaveoCollection");
			return collection;
		} catch (Exception e) {
			logger.error("mongoCollection exception--"+e);
		}
		return null;
	}
	
	public static void insertDocument(String json) {
		try {
			Document document = Document.parse(json);
			mongoCollection.insertOne(document);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
