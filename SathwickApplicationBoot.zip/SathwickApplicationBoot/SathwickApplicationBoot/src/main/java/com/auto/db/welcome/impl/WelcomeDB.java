package com.auto.db.welcome.impl;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;
import org.springframework.stereotype.Repository;

import com.auto.db.welcome.IWelcomeDB;
import com.auto.entity.auth.RegisterUser;
import com.auto.util.mongodb.MongoDbConfig;
import com.google.gson.Gson;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import com.mongodb.client.result.DeleteResult;

@Repository
public class WelcomeDB implements IWelcomeDB{

	@Override
	public List<RegisterUser> getAllUserListDB() {
		List<RegisterUser> list=new ArrayList<RegisterUser>();
		MongoCollection<Document> mongoCollection = MongoDbConfig.mongoCollection;
		 MongoCursor<Document> cursor2 = mongoCollection.find().cursor();//.hasNext();
		 while(cursor2.hasNext()) {
			Document document = cursor2.next();
			String json = document.toJson();
			Gson gson = new Gson();
			list.add( gson.fromJson(json, RegisterUser.class));
		 }
		return list;
	}

	@Override
	public Boolean deleteUserDB(String userName) {

		MongoCollection<Document> mongoCollection = MongoDbConfig.mongoCollection;
		Bson filter = Filters.eq("userName", userName);
		 MongoCursor<Document> cursor2 = mongoCollection.find(filter).cursor();//.hasNext();
		 if(cursor2.hasNext()) {
			DeleteResult deleteOne = mongoCollection.deleteOne(filter);
			System.out.println("deleteOne--"+deleteOne);
			return true;
		 }
		return false;
	
	}

	

}
