package com.auto.util;

public class FaveoConstants {
	  public static final String CLIENT_ID = "FREE_TRIAL_ACCOUNT";
	  public static final String CLIENT_SECRET = "PUBLIC_SECRET";
	  public static final String ENDPOINT = "http://api.whatsmate.net/v1/translation/translate";
}
