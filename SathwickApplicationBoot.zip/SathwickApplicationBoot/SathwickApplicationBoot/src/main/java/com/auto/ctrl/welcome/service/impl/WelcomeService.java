package com.auto.ctrl.welcome.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.auto.ctrl.welcome.WelcomeCtrl;
import com.auto.ctrl.welcome.service.IWelcomeService;
import com.auto.db.welcome.IWelcomeDB;
import com.auto.entity.auth.RegisterUser;
import com.auto.entity.returntype.ServiceReturnList;
import com.auto.entity.returntype.ServiceReturnSingle;

@Service
public class WelcomeService implements IWelcomeService {
	private static final Logger logger = Logger.getLogger(WelcomeCtrl.class);
	@Autowired
	IWelcomeDB welcomeDB;
	private RestTemplate restTemplate = new RestTemplate();
	@Override
	public ServiceReturnList<RegisterUser> allUserService(String apiKey) {
		logger.info("allUserService.....!");
		ServiceReturnList<RegisterUser> serviceReturnList=new ServiceReturnList<RegisterUser>();

		String checkUser = checkUser(apiKey);
		if(checkUser==null) {
			serviceReturnList.setStatusCode(HttpStatus.BAD_REQUEST.value());
			serviceReturnList.setResult(null);	
			
		}
		 else if(checkUser.equalsIgnoreCase("ADMIN")) {
			List<RegisterUser> resultList=welcomeDB.getAllUserListDB();
			serviceReturnList.setStatusCode(HttpStatus.OK.value());
			serviceReturnList.setResult(resultList);
			return serviceReturnList;
		}else {
			serviceReturnList.setStatusCode(HttpStatus.UNAUTHORIZED.value());
			serviceReturnList.setResult(null);
		}
		
		return serviceReturnList;
	}

	@Override
	public ServiceReturnSingle<String> deleteUserService(String apiKey, String userName) {
		try {
			ServiceReturnSingle<String> serviceReturnSingle=new ServiceReturnSingle<String>();

			String checkUser = checkUser(apiKey);
			if(checkUser==null) {
				serviceReturnSingle.setStatusCode(HttpStatus.BAD_REQUEST.value());
				serviceReturnSingle.setResult(null);	
				
			}
			 else if(checkUser.equalsIgnoreCase("ADMIN")) {
				 Boolean isDeleted=welcomeDB.deleteUserDB(userName);
					String result=isDeleted?"Successfully deleted":"Failed to delete";
					serviceReturnSingle.setStatusCode(HttpStatus.OK.value());
					serviceReturnSingle.setResult(result);
			}else {
				serviceReturnSingle.setStatusCode(HttpStatus.UNAUTHORIZED.value());
				serviceReturnSingle.setResult("user authentication fail...");
			}
			return serviceReturnSingle;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public String checkUser(String apiKey) {
		try {
			String url = "http://localhost:8885/SathwickApplication/authuserctrl/authenticationCtrl?apiKey="+apiKey;
//			HttpHeaders headers=new HttpHeaders();
//			headers.setContentType(MediaType.TEXT_PLAIN);
//			MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();
//			map.add("apiKey", apiKey);
//			HttpEntity<String> request = new HttpEntity<String>("{apiKey:asdf}", headers);
			String forObject = restTemplate.getForObject(url, String.class);
			JSONObject parse = (JSONObject) new JSONParser().parse(forObject);
			JSONObject object = (JSONObject) parse.get("rs");
			if(object!=null ){
				String object2 = (String) object.get("role");
				System.out.println("");
				return object2; 	
			}else {
				return "";
			}
 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
