package com.auto.ctrl.welcome.service;

import com.auto.entity.auth.RegisterUser;
import com.auto.entity.returntype.ServiceReturnList;
import com.auto.entity.returntype.ServiceReturnSingle;
import com.auto.entity.welcome.Translator;

public interface IWelcomeService {

	ServiceReturnList<RegisterUser> allUserService(String apiKey);

	ServiceReturnSingle<String> deleteUserService(String apiKey, String userName);


}
