package com.auto.entity.returntype;


import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ServiceReturnSingle<T> extends ServiceReturn<T> {
	
	public static final ServiceReturnSingle<String> pingServiceReturn(String ctrlName, String route) {
		ServiceReturnSingle<String> rs = new ServiceReturnSingle<String>();
		rs.setStatusCode(HttpStatus.OK.value());

		rs.setResult(String.format("Service with name %1s is Up and Running on Route %2s", ctrlName, route));
		return rs;
	}
	public static final ServiceReturnSingle<Boolean> defaultBooleanReturn(Boolean status) {
		ServiceReturnSingle<Boolean> rs = new ServiceReturnSingle<Boolean>();
		rs.setStatusCode(HttpStatus.OK.value());
		rs.setResult(status);
		return rs;
	}
	public static final ServiceReturnSingle<Object> defaultBooleanReturn(Object status) {
		ServiceReturnSingle<Object> rs = new ServiceReturnSingle<Object>();
		rs.setStatusCode(HttpStatus.OK.value());
		rs.setResult(status);
		return rs;
	}
	/*
	 * public static final ServiceReturnSingle EMPTY_RETURN(Class cls){
	 * if(cls.getName().contains("Integer")){ Ser } return null;
	 *
	 * }
	 */

	@JsonProperty(value = "rs")
	private T result;

	public T getResult() {
		return result;
	}

	public void setResult(T result) {
		this.result = result;
	}
}
