package com.auto.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SathwickBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
